<?php

    $lang['site_title'] = "سامانه مدیریت هتل";
    /*------------------------------------------------------*/
    $lang['New CheckIn'] = "ورودی جدید";
    $lang['Full Date'] = "نمایش زمان";
    $lang['View Full list'] = "نمایش لیست کامل";
    $lang['View Details'] = "نمایش جزیات";
    
    $lang['Customer'] = "مشتریان";
    $lang['Today Check-Out !'] = "خروجی های امروز";
    $lang['Today Check-In'] = "ورودی های امروز";
    $lang['System'] = "سیستم";
    $lang['Config Wizard'] = "پیکربندی";
    $lang['Checkout'] = "خروجی ها";
    $lang['Checkin'] = "ورودی ها";
    $lang['Reservation'] = "رزرو ها";
    $lang['User Profile'] = "پروفایل";
    $lang['Setting'] = "تنظیمات";
    $lang['Logout'] = "خروج";
    $lang['Name'] = "نام";
    
    
    







    ?>